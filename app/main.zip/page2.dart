import 'package:flutter/material.dart';

class Page2 extends StatelessWidget{
  Widget build(BuildContext content){
    return Center(
      child: Text(
        '홈 페이지',
        style: TextStyle(fontSize: 40),
      ),
    );
  }
}